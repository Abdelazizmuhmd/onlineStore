$(document).ready(function () {
  $(".Delete").click(function () {
    return confirm("Delete this order?");
  });
});
