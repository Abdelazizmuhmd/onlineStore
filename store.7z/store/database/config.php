<?php
    define('DB_SERVER', "server225.web-hosting.com");
    define('DB_USER', "patsnnhl_patadmin");
    define('DB_PASS', "patadminpat@333");
    define('DB_DATABASE', "patsnnhl_onlinestore");
 ?>