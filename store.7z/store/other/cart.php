<?php

$val=array('name'=>'Guru','country'=>'USA');


  $ar=json_encode($val);
  setcookie('cook',$ar);




//echo $_COOKIE["cook"];
?>
<html >
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">

  <title>
Pat  
    </title>

  <link href="../css/home.css" rel="stylesheet" type="text/css" media="all" /> 
  <script src="js/j.js" type="text/javascript"></script>
  <script src="js/s.js" type="text/javascript"></script>
  <script src="js/home.js" type="text/javascript"></script>
  <script src="js/j2.js" type="text/javascript"></script>

    

</head>

    
    
    
<body >
  <div>
    <a href="" class="announcement-bar announcement-bar--link">
    <p class="announcement-bar__message site-wrapper">WELCOME TO  PAT</p>
    </a>
  


<div class="site-wrapper">
  <div class="top-bar grid">

      <div class="grid__item medium-up--two-fifths small--hide" style="margin-left: 140px;">
        <span class="customer-links small--hide">
            <a href="" id="customer_login_link">Log in</a>
            <span class="vertical-divider"></span>
            <a href="" id="customer_register_link">Sign up</a>
          
        </span>
      </div>
    

    <div class="grid__item  medium-up--two-fifths  small--one-half text-right">
      <a href="" class="site-header__cart">
        <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-cart" viewBox="0 0 20 20"><path fill="#444" d="M18.936 5.564c-.144-.175-.35-.207-.55-.207h-.003L6.774 4.286c-.272 0-.417.089-.491.18-.079.096-.16.263-.094.585l2.016 5.705c.163.407.642.673 1.068.673h8.401c.433 0 .854-.285.941-.725l.484-4.571c.045-.221-.015-.388-.163-.567z"/><path fill="#444" d="M17.107 12.5H7.659L4.98 4.117l-.362-1.059c-.138-.401-.292-.559-.695-.559H.924c-.411 0-.748.303-.748.714s.337.714.748.714h2.413l3.002 9.48c.126.38.295.52.942.52h9.825c.411 0 .748-.303.748-.714s-.336-.714-.748-.714zM10.424 16.23a1.498 1.498 0 1 1-2.997 0 1.498 1.498 0 0 1 2.997 0zM16.853 16.23a1.498 1.498 0 1 1-2.997 0 1.498 1.498 0 0 1 2.997 0z"/></svg>
        <span class="small--hide">
          Cart
          (<span id="CartCount">0</span>)
        </span>
      </a>
    </div>
      
  </div>
  <hr class="small--hide hr--border">
    
  <header style="height:115px;">
          <div id="HeaderLogoWrapper" class="supports-js" style="height:115px;">
            <a href="" itemprop="url" style="padding-top:19.601328903654487%;  display: block;width:100px;height:100px;">
              <img id="HeaderLogo" 
                   src="images/logo.png"
                   data-widths="[180, 360, 540, 720, 900, 1080, 1296, 1512, 1728, 2048]"
                   data-aspectratio=""
                   data-sizes="auto"
                   alt="Pat"
                   itemprop="logo"
                   style="width:90px;height:90px;"
                   >
            </a>
          </div>
 
  </header>
</div>




</div>

    

  <div class="site-wrapper">

    <div class="grid">

      <div id="shopify-section-sidebar" class="shopify-section"><div data-section-id="sidebar" data-section-type="sidebar-section">
  <nav class="grid__item small--text-center medium-up--one-fifth" role="navigation">
    <hr class="hr--small medium-up--hide">
    <button id="ToggleMobileMenu" class="mobile-menu-icon medium-up--hide" aria-haspopup="true" aria-owns="SiteNav">
      <span class="line"></span>
      <span class="line"></span>
      <span class="line"></span>
      <span class="line"></span>
      <span class="icon__fallback-text">Menu</span>
    </button>
    <div id="SiteNav" class="site-nav" role="menu">
      <ul class="list--nav">
        
<!-- repeat all that to add section-->
            <li class="site-nav--has-submenu site-nav__item">
              <button class="site-nav__link btn--link site-nav__collapse" aria-expanded="true" aria-controls="Collapsible-2">
                Menu
                <span class="site-nav__link__text" aria-hidden="true">-</span>
              </button>
              <ul id="Collapsible-2" class="site-nav__submenu site-nav__submenu--expanded" aria-hidden="false">
                  <li class="site-nav--active">
                      <a href="" class="site-nav__link" aria-current="page">Tee</a>
                    </li>
                  
                
                  
                    <li >
                      <a href="" class="site-nav__link">Sweater</a>
                    </li>
                  
                
                  
                    <li >
                      <a href="" class="site-nav__link">Hoodie</a>
                    </li>
                  
                
                  
                    <li >
                      <a href="" class="site-nav__link">Bag</a>
                    </li>
                  
                
              </ul>
                
            </li>
          

      </ul>
      <ul class="list--inline social-links">
        
          <li>
            <a href="" title=" on Facebook">
              <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-facebook" viewBox="0 0 20 20"><path fill="#444" d="M18.05.811q.439 0 .744.305t.305.744v16.637q0 .439-.305.744t-.744.305h-4.732v-7.221h2.415l.342-2.854h-2.757v-1.83q0-.659.293-1t1.073-.342h1.488V3.762q-.976-.098-2.171-.098-1.634 0-2.635.964t-1 2.72V9.47H7.951v2.854h2.415v7.221H1.413q-.439 0-.744-.305t-.305-.744V1.859q0-.439.305-.744T1.413.81H18.05z"/></svg>
              <span class="icon__fallback-text">Facebook</span>
            </a>
          </li>
        
        
        
        
          <li>
            <a href="" title=" on Instagram">
              <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-instagram" viewBox="0 0 512 512"><path d="M256 49.5c67.3 0 75.2.3 101.8 1.5 24.6 1.1 37.9 5.2 46.8 8.7 11.8 4.6 20.2 10 29 18.8s14.3 17.2 18.8 29c3.4 8.9 7.6 22.2 8.7 46.8 1.2 26.6 1.5 34.5 1.5 101.8s-.3 75.2-1.5 101.8c-1.1 24.6-5.2 37.9-8.7 46.8-4.6 11.8-10 20.2-18.8 29s-17.2 14.3-29 18.8c-8.9 3.4-22.2 7.6-46.8 8.7-26.6 1.2-34.5 1.5-101.8 1.5s-75.2-.3-101.8-1.5c-24.6-1.1-37.9-5.2-46.8-8.7-11.8-4.6-20.2-10-29-18.8s-14.3-17.2-18.8-29c-3.4-8.9-7.6-22.2-8.7-46.8-1.2-26.6-1.5-34.5-1.5-101.8s.3-75.2 1.5-101.8c1.1-24.6 5.2-37.9 8.7-46.8 4.6-11.8 10-20.2 18.8-29s17.2-14.3 29-18.8c8.9-3.4 22.2-7.6 46.8-8.7 26.6-1.3 34.5-1.5 101.8-1.5m0-45.4c-68.4 0-77 .3-103.9 1.5C125.3 6.8 107 11.1 91 17.3c-16.6 6.4-30.6 15.1-44.6 29.1-14 14-22.6 28.1-29.1 44.6-6.2 16-10.5 34.3-11.7 61.2C4.4 179 4.1 187.6 4.1 256s.3 77 1.5 103.9c1.2 26.8 5.5 45.1 11.7 61.2 6.4 16.6 15.1 30.6 29.1 44.6 14 14 28.1 22.6 44.6 29.1 16 6.2 34.3 10.5 61.2 11.7 26.9 1.2 35.4 1.5 103.9 1.5s77-.3 103.9-1.5c26.8-1.2 45.1-5.5 61.2-11.7 16.6-6.4 30.6-15.1 44.6-29.1 14-14 22.6-28.1 29.1-44.6 6.2-16 10.5-34.3 11.7-61.2 1.2-26.9 1.5-35.4 1.5-103.9s-.3-77-1.5-103.9c-1.2-26.8-5.5-45.1-11.7-61.2-6.4-16.6-15.1-30.6-29.1-44.6-14-14-28.1-22.6-44.6-29.1-16-6.2-34.3-10.5-61.2-11.7-27-1.1-35.6-1.4-104-1.4z"/><path d="M256 126.6c-71.4 0-129.4 57.9-129.4 129.4s58 129.4 129.4 129.4 129.4-58 129.4-129.4-58-129.4-129.4-129.4zm0 213.4c-46.4 0-84-37.6-84-84s37.6-84 84-84 84 37.6 84 84-37.6 84-84 84z"/><circle cx="390.5" cy="121.5" r="30.2"/></svg>
              <span class="icon__fallback-text">Instagram</span>
            </a>
          </li>

      </ul>
    </div>
    <hr class="medium-up--hide hr--small ">
  </nav>
</div>

</div>
<main class="main-content grid__item medium-up--four-fifths" id="MainContent" role="main">
        
          <hr class="hr--border-top small--hide">
        
        
        <!-- /templates/cart.liquid -->

<div class="grid">
  <div class="grid__item">
    
      <h1 class="h2 visually-hidden">Shopping Cart</h1>
      <form action="/cart" method="post" novalidate="" class="cart pf-form-processed">
        <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-K7ZCRLW"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<?php
if(isset($_COOKIE['cook'])){
$return=$_COOKIE['cook'];
$arr=json_decode($return, true);
foreach($arr as $key1 => $values)
{ 
  echo $key1.' : '.$values.'<br>';

echo "<table class='cart-table responsive-table table--no-border'>
          <thead class='cart__row cart__header-labels small--hide'>

            <tr><th class='text-left cart__table-cell--image'>Product</th>
            <th class='text-center cart__table-cell--meta'></th>
            <th class='text-right cart__table-cell--price'>Price</th>
            <th class='text-right cart__table-cell--quantity'>Quantity</th>
            <th class='text-right cart__table-cell--line-price'>Total</th>
          </tr></thead>
          <tbody>
            
      <tr class='cart__row responsive-table__row'>
      <td class='cart__table-cell--image small--text-center'>
                  


                    <div id='CartImageWrapper--13760170131490' class='cart__image-wrapper supports-js'>
                      <a class='cart__image-container' href='/collections/all/products/im-fine-phr-2?variant=31415765139490' style='padding-top:100.0%;'>
                        <img id='CartImage--13760170131490' class='cart__image' src='../images/c.jpg' data-widths='[180, 230, 360, 540, 720, 900, 1080, 1296, 1512, 1728, 2048]' data-aspectratio='1.0' data-sizes='auto' alt='I'm fine (phr.) - White / S' itemprop='image'>
                      </a>
                    </div>
                </td>
                <td class='cart__table-cell--meta text-center large-up--text-left'>
                  <p>
                    <a href='/products/im-fine-phr-2?variant=31415765139490'>I'm fine (phr.)</a>
                      <br><small>White / S</small>
                    </p><div class='hulkapps-reminder'></div>
                  <p></p>

                  <p class='txt--minor'>
                    <a href='/cart/change?line=1&amp;quantity=0' class='cart__remove'>Remove</a>
                  </p>
                </td>
                <td class='cart__table-cell--price medium-up--text-right' data-label='Price'><span class='hulkapps-cart-item-price' >30,00 L.E </span>
</td>
                <td data-label='Quantity' class='medium-up--text-right cart__table-cell--quantity'>
                  <span class='hulkapps-cart-item-line-price' >$values[name] </span></td>


                <td data-label='Total' class='text-right cart__table-cell--line-price'><span class='hulkapps-cart-item-line-price'   >30,00 L.E </span></td>
              </tr>
          </tbody>
        </table>";

        }}

?>
        <footer class="cart__footer">
          <div class="grid">
            <div class="grid__item large-up--one-half">
              <label for="CartSpecialInstructions" class="label--block">Special instructions for seller</label>
              <textarea name="note" id="CartSpecialInstructions" class="input--block cart__note"></textarea>
            </div>
            <div class="grid__item text-center large-up--one-half large-up--text-right"><p>
                <span class="cart__subtotal-title h3">Subtotal</span>
                <span class="cart__subtotal h3"><span class="hulkapps-cart-original-total">30,00 L.E </span></span>
              </p><p class="cart__policies txt--emphasis rte">Tax included. Delivered to your door</p>
              <p>
              
                <a class="btn btn--secondary" href="/collections/all">Continue shopping</a>
              </p>
              <p>
                <button type="submit" name="checkout" class="btn">Check Out</button>
              </p>
            </div>
          </div>
        </footer>
      </form>
    
  </div>
</div>

      </main>
</div>
<hr>
</div>  
</body>
</html>
