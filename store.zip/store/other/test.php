<?php 
require_once("../database/db.php");
$db=new Database();
$db->connect();
echo"dasda";
?>